package com.example.bank.model;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String transactiontype;
	double amount;
	
	LocalDateTime transactiondate;  //Built-in-method
	
	@ManyToOne 
	@JoinColumn(name="account_id")
	Account account; //Object created for account model//

	public Transaction(String transationtype, double amount, LocalDateTime transactiondate, Account account) {
		super();
		this.transactiontype = transationtype;
		this.amount = amount;
		this.transactiondate = transactiondate;
		this.account = account;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTransationtype() {
		return transactiontype;
	}

	public void setTransationtype(String transationtype) {
		this.transactiontype = transationtype;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDateTime getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(LocalDateTime transactiondate) {
		this.transactiondate = transactiondate;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setTransactiondate(String string) {
		// TODO Auto-generated method stub
		
	}
}
