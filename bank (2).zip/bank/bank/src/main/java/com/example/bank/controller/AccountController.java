package com.example.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;
import com.example.bank.model.*;
import com.example.bank.service.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	
	@Autowired
	AccountService as; //Creating object for service file //
	
	@PostMapping("/addaccount") // accounts/addaccount //
	public Account get1(@RequestBody Account a)  
	{
		return as.createaccount(a);
	}
	
	@GetMapping(" /selectall")
	public List<Account> get2()
	{
		return as.viewallaccount();
	}
	
	@GetMapping(" /part/{id}/")
	public List<Account> get3()
	{
		return as.viewallaccount();
	}
	
	@GetMapping("/part/{id}")
	public Account get3(@PathVariable int id)
	{
		return as.partaccount(id);
	}
	
	 @PutMapping("/deposit/{id}/{amount}")
	 public Account get4(@PathVariable int id,@PathVariable double amount)
	 {
		 return as.deposit(id,  amount);
	 }
	 
	 @PutMapping("/withdraw/{id}/{amount}")
	 public Account get5(@PathVariable int id,@PathVariable double amount)
	 {
		 return as.withdraw(id, amount);
	 }
}
