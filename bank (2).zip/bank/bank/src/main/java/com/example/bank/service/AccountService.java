package com.example.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.bank.model.*;
import com.example.bank.dao.*;

import java.time.LocalDateTime;
import java.util.*;
@Service
public class AccountService {

	@Autowired
    AccountRepo ar;
	@Autowired
    TransRepo tr;
	
	public Account createaccount(Account a)
	{
		return ar.save(a);
	}
	
	public List<Account> viewallaccount()
	{
		return ar.findAll();
	}
	public Account partaccount(int id)
	{
		return ar.findById(id).orElse(null);
	}
	
	public Account deposit(int id, double amount)
	{
		Account ac = ar.findById(id).orElse(null);
		if(ac!=null)
		{
			ac.setBalance(ac.getBalance()+amount);
			Transaction tc = new Transaction();
			tc.setTransationtype("DEPOSIT");
			tc.setTransactiondate(LocalDateTime.now());
			tc.setAccount(ac);
			tr.save(tc);
			return ar.save(ac);
			
		}
		else
		{
			return null;
		}
	}
	public Account withdraw(int id, double amount)
	{
		Account ac = ar.findById(id).orElse(null); //Creating an obj for Account & @ the same tym checking cond//
		if(ac != null && ac.getBalance()>=amount)
		{
			ac.setBalance(ac.getBalance()-amount);
			Transaction tc = new Transaction();
			tc.setTransationtype("WITHDRAW");
			tc.setTransactiondate(LocalDateTime.now());
			tc.setAccount(ac);
			tr.save(tc);
			return ar.save(ac);
		}
		else
		{
			return null;
		}
	}
}
